from typing import Any, Optional
import torch
import time
from torchmetrics import MeanMetric, JaccardIndex
import pytorch_lightning as pl


class SegmentationTask(pl.LightningModule):
    def __init__(
        self,
        model,
        num_classes,
        criterion,
        optimizer,
        config,
        scheduler=None,
    ):

        super().__init__()
        self.model = model
        self.num_classes = num_classes
        self.criterion = criterion
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.config = config

    def setup(self, stage=None):
        if stage == "fit":
            self.train_epoch_loss, self.val_epoch_loss = None, None
            self.train_epoch_metrics, self.val_epoch_metrics = None, None
            # Intersection over union or Jaccard index calculation
            self.train_metrics = JaccardIndex(
                task="multiclass", num_classes=self.num_classes
            )
            self.val_metrics = JaccardIndex(
                task="multiclass", num_classes=self.num_classes
            )
            self.train_loss = MeanMetric()
            self.val_loss = MeanMetric()

        elif stage == "validate":
            self.val_epoch_loss, self.val_epoch_metrics = None, None
            self.val_metrics = JaccardIndex(
                task="multiclass", num_classes=self.num_classes
            )
            self.val_loss = MeanMetric()

    def on_train_start(self):
        self.logger.log_hyperparams(self.config)

    # modified
    def forward(self, config, input_patch, input_spatch, input_dates, input_mtd):
        logits = self.model(config, input_patch, input_spatch, input_dates, input_mtd)
        return logits

    def step(self, batch):
        patch = batch["patch"]
        mtd = batch["mtd"]
        spatch = batch["spatch"]
        dates = batch["dates"]
        targets = batch["labels"].long()
        targets_sp = batch["slabels"].long()
        logits_utae, logits_unet = self.model(self.config, patch, spatch, dates, mtd)

        loss_unet = self.criterion[0](logits_unet, targets) # aerial images
        loss_utae = self.criterion[1](logits_utae, targets_sp) # satellite images
        
        loss = (
            loss_utae * self.config["w_unet_utae"][0]
            + loss_unet * self.config["w_unet_utae"][1]
        ) # loss is the sum of aerial and satellite losses

        with torch.no_grad():
            preds = logits_unet.argmax(dim=1)
        return loss, preds, targets

    def training_step(self, batch, batch_idx):
        loss, preds, targets = self.step(batch)
        self.train_loss.update(loss)
        self.train_metrics(preds=preds, target=targets)
        self.log(
            "train_loss",
            loss, 
            on_step=False, 
            on_epoch=True, 
            prog_bar=True, 
            sync_dist=False,
            logger=True
        )
        return {"loss": loss, "preds": preds, "targets": targets}

    def on_train_epoch_start(self):
        self.start_time = time.time()

    def on_train_epoch_end(self):
        print(f"Time for epoch {self.current_epoch}: {time.time() - self.start_time}")
        self.train_epoch_loss = self.train_loss.compute()
        self.train_epoch_metrics = self.train_metrics.compute()
        
        self.log(
            "train_loss",
            self.train_epoch_loss,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=False,
            rank_zero_only=True,
        )

        self.train_loss.reset()
        self.train_metrics.reset()

    def validation_step(self, batch, batch_idx):
        loss, preds, targets = self.step(batch)
        self.val_loss.update(loss)
        self.val_metrics(preds=preds, target=targets)
        return {"loss": loss, "preds": preds, "targets": targets}

    def on_validation_epoch_end(self):
        self.val_epoch_loss = self.val_loss.compute()
        self.val_epoch_metrics = self.val_metrics.compute()
        self.log(
            "val_loss",
            self.val_epoch_loss,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=False,
            rank_zero_only=True,
        )
        self.log(
            "val_miou",
            self.val_epoch_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=False,
            rank_zero_only=True,
        )

        self.val_loss.reset()
        self.val_metrics.reset()

    def lr_scheduler_step(self, scheduler, metric):
        scheduler.step(epoch=self.current_epoch)
    
    def predict_step(self, batch, batch_idx, dataloader_idx=0):

        _, logits_unet = self.forward(
            self.config, batch["patch"], batch["spatch"], batch["dates"], batch["mtd"]
        )
        proba = torch.softmax(logits_unet, dim=1)
        batch["preds"] = torch.argmax(proba, dim=1)
        return batch

    def configure_optimizers(self):
        if self.scheduler is not None:
            lr_scheduler_config = {
                "scheduler": self.scheduler,
                "interval": "epoch",
                "monitor": "val_loss",
                "frequency": 1,
                "strict": True,
                "name": "Scheduler",
            }
            config_ = {"optimizer": self.optimizer, "lr_scheduler": lr_scheduler_config}
            return config_
        else:
            return self.optimizer
